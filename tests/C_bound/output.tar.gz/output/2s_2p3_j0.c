OI                                                                              
  1s                                                                            
  2s( 1)  2p( 3)                                                
 2S1 2P1 3P                                                 
*
