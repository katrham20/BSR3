OI                                                                                                                                                                                                      
  1s                                                                                                                                                                                                    
 2s3( 1) 2p4( 3)                                                 1.00000000
 2S1 2D3 3D
*
npert =    1
    1

Physical orbitals:
 2s3     1.0      2s1   0.998
 2p4     3.0      2p1   0.984
*

Spectroscopic configurations:

 2s1( 1) 2p1( 3)                                                 1.00000000
 2S1 2D3 3D
*
