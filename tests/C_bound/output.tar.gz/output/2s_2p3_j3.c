OI                                                                              
  1s                                                                            
  2s( 1)  2p( 3)                                                
 2S1 2D3 3D                                                 
*
