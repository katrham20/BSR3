                   -36.78943785                                                                                                                                                                         
  1s                                                                                                                                                                                                    
 2s2( 1) 2p3( 2)                                                 1.00000000
 2S1 3P2 2P
*

Physical orbitals:
 2s2     1.0      2s1   1.000
 2p3     2.0      2p1   1.000
*

Spectroscopic configuration:

 2s1( 1) 2p1( 2)                                                 1.00000000 1.00000000
 2S1 3P2 2P
