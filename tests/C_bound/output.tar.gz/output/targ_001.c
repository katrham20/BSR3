                   -37.34552249                                                                                                                                                                         
  1s                                                                                                                                                                                                    
 2s1( 2) 2p1( 1)                                                -0.97633652
 1S0 2P1 2P
 2p2( 3)                                                        -0.21625680
 2P1
*

Physical orbitals:
 2s1     1.9      2s1   1.000
 2p1     1.0      2p1   1.000
*

Spectroscopic configuration:

 2s1( 2) 2p1( 1)                                                 1.00000000 0.97633652
 1S0 2P1 2P
