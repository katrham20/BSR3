                   -36.50131416                                                                                                                                                                         
  1s                                                                                                                                                                                                    
 2p2( 3)                                                        -0.97633652
 2P1
 2s1( 2) 2p1( 1)                                                 0.21625680
 1S0 2P1 2P
*

Physical orbitals:
 2p2     2.9      2p1   1.000
*

Spectroscopic configuration:

 2p1( 3)                                                         1.00000000 0.97633652
 2P1
